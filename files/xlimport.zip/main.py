# main.py

from pathlib import Path

from openpyxl import load_workbook

from config_loader import load_config
from constants import PIXELS_PER_COLUMN, SPACE_COLUMNS, SUPPORTED_EXTENSIONS
from excel_utils import clear_images_from_row, get_or_create_sheet, place_comment, place_image_after_existing, place_images
from file_utils import find_excel_file, find_named_file, get_target_dir, list_image_files


def get_mode(conf: dict) -> str:
    mode = str(conf.get("mode", "0"))
    if mode not in {"0", "1"}:
        raise ValueError(f"unsupported mode: {mode}")

    return mode


def initialize_sheet(worksheet, sheet_configs: list[dict]) -> None:
    # シート自体は残し、今回上書きする範囲だけを掃除する
    cleared_image_cells: set[str] = set()
    cleared_comment_cells: set[str] = set()

    for conf in sheet_configs:
        image_start_cell = conf["image_start_cell"]
        if image_start_cell not in cleared_image_cells:
            clear_images_from_row(worksheet, image_start_cell)
            cleared_image_cells.add(image_start_cell)

        comment_start_cell = conf.get("comment_start_cell")
        if comment_start_cell and comment_start_cell not in cleared_comment_cells:
            worksheet[comment_start_cell].value = None
            cleared_comment_cells.add(comment_start_cell)


def group_configs_by_sheet(configs: list[dict]) -> dict[str, list[dict]]:
    grouped_configs: dict[str, list[dict]] = {}
    for conf in configs:
        sheet_name = conf["sheet"]
        grouped_configs.setdefault(sheet_name, []).append(conf)

    return grouped_configs


def process_mode_zero(target_dir: Path, worksheet, conf: dict) -> None:
    folder_name = conf["folder"]
    image_start_cell = conf["image_start_cell"]

    # 画像フォルダの実パスを組み立てる
    folder_path = target_dir / folder_name
    if not folder_path.is_dir():
        raise FileNotFoundError(f"image folder not found: {folder_path}")

    # フォルダ内の画像を「更新日時が古い順」で取得
    image_files = list_image_files(folder_path, SUPPORTED_EXTENSIONS)

    # 画像があればExcelへ貼り付け
    if image_files:
        place_images(
            worksheet=worksheet,
            image_paths=image_files,
            start_cell=image_start_cell,
            pixels_per_column=PIXELS_PER_COLUMN,
            space_columns=SPACE_COLUMNS
        )


def process_mode_one(target_dir: Path, worksheet, conf: dict) -> None:
    folder_name = conf["folder"]
    image_name = conf["image"]
    image_start_cell = conf["image_start_cell"]
    folder_path = target_dir / folder_name
    image_path = folder_path / image_name

    if not folder_path.is_dir():
        raise FileNotFoundError(f"image folder not found: {folder_path}")
    if not image_path.is_file():
        raise FileNotFoundError(f"image file not found: {image_path}")
    if image_path.suffix.lower() not in SUPPORTED_EXTENSIONS:
        raise ValueError(f"unsupported image extension: {image_path.suffix}")

    place_image_after_existing(
        worksheet=worksheet,
        image_path=image_path,
        start_cell=image_start_cell,
        pixels_per_column=PIXELS_PER_COLUMN,
        space_columns=SPACE_COLUMNS
    )


def process_sheet_config(target_dir: Path, worksheet, conf: dict) -> None:
    comments = conf.get("comments", "")
    comment_start_cell = conf.get("comment_start_cell")
    mode = get_mode(conf)

    if mode == "0":
        process_mode_zero(target_dir, worksheet, conf)
    else:
        process_mode_one(target_dir, worksheet, conf)

    # コメント貼り付けセルが指定されていれば書き込む
    if comment_start_cell:
        place_comment(
            worksheet=worksheet,
            comment_text=comments,
            comment_start_cell=comment_start_cell
        )


def main() -> None:
    # 実行対象ディレクトリを取得
    target_dir = get_target_dir()

    # 対象ディレクトリ名と同名のJSONとExcelを特定
    json_path = find_named_file(target_dir, ".json")
    excel_path = find_excel_file(target_dir)

    # 設定ファイル読込
    configs = load_config(json_path)
    configs_by_sheet = group_configs_by_sheet(configs)

    # Excelブック読込
    workbook = load_workbook(excel_path)
    worksheets = {}

    for sheet_name, sheet_configs in configs_by_sheet.items():
        worksheet = get_or_create_sheet(workbook, sheet_name)
        initialize_sheet(worksheet, sheet_configs)
        worksheets[sheet_name] = worksheet

    # JSONの各設定を順に処理
    for conf in configs:
        worksheet = worksheets[conf["sheet"]]
        process_sheet_config(target_dir, worksheet, conf)

    # 上書き保存
    workbook.save(excel_path)


if __name__ == "__main__":
    main()
