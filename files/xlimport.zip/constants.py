# constants.py

# 画像1枚が何列ぶん使うかを概算するための基準値
PIXELS_PER_COLUMN = 64

# 画像と画像の間に空ける列数
SPACE_COLUMNS = 2

# 読み込み対象とする画像拡張子
SUPPORTED_EXTENSIONS = {".png", ".jpg", ".jpeg"}

# openpyxl で扱える Excel 拡張子
SUPPORTED_EXCEL_EXTENSIONS = {".xlsx", ".xlsm", ".xltx", ".xltm"}
