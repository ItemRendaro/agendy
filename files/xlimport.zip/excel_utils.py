# excel_utils.py

from pathlib import Path

from openpyxl.drawing.image import Image
from openpyxl.styles import Alignment
from openpyxl.utils import get_column_letter, column_index_from_string
from openpyxl.worksheet.worksheet import Worksheet


def get_or_create_sheet(workbook, sheet_name: str) -> Worksheet:
    # シートがあれば取得し、なければ新規作成する
    if sheet_name in workbook.sheetnames:
        return workbook[sheet_name]

    return workbook.create_sheet(title=sheet_name)


def parse_cell_address(cell_address: str) -> tuple[int, int]:
    # "B2" のようなセル番地を
    # (列番号, 行番号) に分解する
    col_letters = "".join(c for c in cell_address if c.isalpha())
    row_numbers = "".join(c for c in cell_address if c.isdigit())

    if not col_letters or not row_numbers:
        raise ValueError(f"invalid cell address: {cell_address}")

    col_index = column_index_from_string(col_letters)
    row_index = int(row_numbers)

    return col_index, row_index


def place_images(
    worksheet: Worksheet,
    image_paths: list[Path],
    start_cell: str,
    pixels_per_column: int,
    space_columns: int
) -> None:
    # 指定セルから右方向へ画像を順番に貼り付ける
    current_col, row = parse_cell_address(start_cell)

    for image_path in image_paths:
        img = Image(str(image_path))

        # 現在位置のセル番地を作成
        cell = f"{get_column_letter(current_col)}{row}"

        # 画像を貼り付け
        worksheet.add_image(img, cell)

        # 次の画像配置位置を計算
        # 画像幅をもとに何列ぶん使うかを概算する
        columns_used = int(img.width / pixels_per_column) + 1

        # 画像幅ぶん + 指定列数ぶん空けて次へ進める
        current_col += columns_used + space_columns


def get_image_columns(image: Image, pixels_per_column: int) -> int:
    # 画像幅から占有列数を概算する
    return int(image.width / pixels_per_column) + 1


def iter_positioned_images(worksheet: Worksheet):
    # 位置情報を持つ画像だけを順に返す
    for existing_image in getattr(worksheet, "_images", []):
        anchor = getattr(existing_image, "anchor", None)
        marker = getattr(anchor, "_from", None)
        if marker is None:
            continue

        image_col = marker.col + 1
        image_row = marker.row + 1
        yield existing_image, image_col, image_row


def get_image_at_cell(worksheet: Worksheet, cell_address: str):
    # 指定セルを起点にした画像を返す
    target_col, target_row = parse_cell_address(cell_address)

    for existing_image, image_col, image_row in iter_positioned_images(worksheet):
        if image_col == target_col and image_row == target_row:
            return existing_image

    return None


def get_next_image_column(
    worksheet: Worksheet,
    start_cell: str,
    pixels_per_column: int,
    space_columns: int
) -> int:
    # 開始セルに画像がある場合だけ、次に貼るべき列位置を計算する
    start_col, start_row = parse_cell_address(start_cell)
    next_col = start_col

    for existing_image, image_col, image_row in iter_positioned_images(worksheet):
        if image_row != start_row or image_col < start_col:
            continue

        columns_used = get_image_columns(existing_image, pixels_per_column)
        candidate_col = image_col + columns_used + space_columns
        if candidate_col > next_col:
            next_col = candidate_col

    return next_col


def clear_images_from_row(worksheet: Worksheet, start_cell: str) -> None:
    # 指定セルの行にある画像を開始列以降だけ削除する
    start_col, start_row = parse_cell_address(start_cell)
    remaining_images = []

    for existing_image in getattr(worksheet, "_images", []):
        anchor = getattr(existing_image, "anchor", None)
        marker = getattr(anchor, "_from", None)
        if marker is None:
            remaining_images.append(existing_image)
            continue

        image_col = marker.col + 1
        image_row = marker.row + 1
        if image_row == start_row and image_col >= start_col:
            continue

        remaining_images.append(existing_image)

    worksheet._images = remaining_images


def place_image_after_existing(
    worksheet: Worksheet,
    image_path: Path,
    start_cell: str,
    pixels_per_column: int,
    space_columns: int
) -> None:
    # 既存画像があればその右隣、なければ開始セルに1枚貼る
    current_col, row = parse_cell_address(start_cell)
    start_image = get_image_at_cell(worksheet, start_cell)
    if start_image is not None:
        current_col = get_next_image_column(
            worksheet=worksheet,
            start_cell=start_cell,
            pixels_per_column=pixels_per_column,
            space_columns=space_columns
        )
    cell = f"{get_column_letter(current_col)}{row}"
    worksheet.add_image(Image(str(image_path)), cell)


def place_comment(worksheet: Worksheet, comment_text: str, comment_start_cell: str) -> None:
    # コメント文字列を指定セルに書き込む
    worksheet[comment_start_cell] = comment_text

    # 改行が見やすいように折り返し設定を有効化する
    worksheet[comment_start_cell].alignment = Alignment(wrap_text=True)
