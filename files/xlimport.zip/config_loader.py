# config_loader.py

import json
from pathlib import Path


def load_config(json_path: Path) -> list[dict]:
    # JSON設定ファイルを読み込んで返す
    with json_path.open("r", encoding="utf-8") as f:
        return json.load(f)