# file_utils.py

import sys
from pathlib import Path

from constants import SUPPORTED_EXCEL_EXTENSIONS


def get_target_dir() -> Path:
    # 実行引数から対象ディレクトリを取得する
    # 例: python main.py test
    if len(sys.argv) < 2:
        raise SystemExit("usage: python main.py [folder名]")

    target_dir = Path(sys.argv[1]).resolve()

    if not target_dir.is_dir():
        raise SystemExit(f"directory not found: {target_dir}")

    return target_dir


def find_named_file(base_dir: Path, extension: str) -> Path:
    # ディレクトリ名と同名のファイルを取得する
    file_path = base_dir / f"{base_dir.name}{extension}"
    if not file_path.is_file():
        raise SystemExit(f"{extension} file not found: {file_path}")

    return file_path


def find_excel_file(base_dir: Path) -> Path:
    # ディレクトリ名と同名の Excel ファイルを取得する
    for extension in sorted(SUPPORTED_EXCEL_EXTENSIONS):
        file_path = base_dir / f"{base_dir.name}{extension}"
        if file_path.is_file():
            return file_path

    legacy_excel = base_dir / f"{base_dir.name}.xls"
    if legacy_excel.is_file():
        raise SystemExit(
            f".xls is not supported by openpyxl: {legacy_excel}. "
            "Please convert it to .xlsx."
        )

    raise SystemExit(f"Excel file not found for directory name: {base_dir.name}")


def list_image_files(folder_path: Path, supported_extensions: set[str]) -> list[Path]:
    # フォルダ内の画像一覧を取得する
    # 並び順は「更新日時が古い順」、同一時刻ならファイル名順
    return sorted(
        [
            p for p in folder_path.iterdir()
            if p.is_file() and p.suffix.lower() in supported_extensions
        ],
        key=lambda p: (p.stat().st_mtime, p.name.lower())
    )
